package com.plp.springjpa.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.plp.springjpa.dao.BankDaoImpl;
import com.plp.springjpa.entity.Bank;
import com.plp.springjpa.entity.Transaction;

class MyException extends Exception
{
	private static final long serialVersionUID = 1L;
	String s1;
	MyException(String s)
	{
		 s1=s;
	}
	public String toString()
	{
		return (s1);
	}
}
@Service("bankService")
public class BankServiceImpl implements BankService
{
	int balance;
	@Autowired
	private BankDaoImpl bankDao;

	public boolean createAccount(String name, String phoneNo, String password, long accountNo, int balance) {
		
		Bank bank = new Bank();
	    bank.setName(name);
	    bank.setPhoneNo(phoneNo);
	    bank.setPassword(password);
	    bank.setAccountNo(accountNo);
	    bank.setBalance(balance);
	    
	    boolean result = bankDao.createAccount(bank);
		
	    return result;
	}

	public int showBalance(long accountNo) {
	
		balance = bankDao.showBalance(accountNo);
	
		 return balance;
	}

	public int depositAmount(long accountNo, int deposit) {
		int balance;
	
		 balance = bankDao.depositBalance(accountNo, deposit);
		 return balance;
	}

	public int withdrawAmount(long accountNo, int withdraw) {
		int balance;
		
		 balance = bankDao.withdrawAmount(accountNo,withdraw);
		 return balance;
	}

	public boolean fundTransfer(long accountNo, long accno, int amount) {
	
		boolean fund = bankDao.fundTransfer(accountNo,accno,amount);
	      return fund;
	}

	public boolean validateAccount(long accountNo, String password) {
	
		boolean b = bankDao.validateAccount(accountNo,password);
	    return b;
	}

	public List<Transaction> getTransaction(long accountNo) {

	   List<Transaction> l = bankDao.getTransactions(accountNo);
	
	   return l;
	}

	public int passwordValidate(String password) {
		try
		{
		if(password.length()<5)
			return 1;
		else
			throw new MyException("Account Pin Should Be 4 digits..");
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
			return 0;
	}

	public int checkBalance(int balance) {
		if(balance>=1000)
		return 1;
		else 
			return 0;
	}

	public int mobNoValidate(String phoneNo) {
		try
		{
			if(phoneNo.matches("[6-9][0-9]{9}"))
					return 1;
			else
				throw new MyException("Mobile Number is not valid..");
				
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
		return 0;
	}

	public int nameValidate(String name) {
		try
		{
		if(name.matches("[A-Z][a-zA-Z]*"))
			return 1;
		
		else
		throw new MyException("Name Should Start With Capital Letter..");
	}
		catch(MyException e)
		{
			System.out.println(e);
		}
		return 0;
	}
	
}