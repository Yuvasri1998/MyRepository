package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.beans.Customer;

public class CustomerData {

	static public Map<Integer, Customer> hm=new HashMap<>();
	
	static
	{
		hm.put(7493,  new Customer("Yamini", "96665858625", "yaminiambati1997@gmail.com", 7493, 660f));
		hm.put(1234,  new Customer("Asha", "7674810556", "asha1221@gmail.com", 1234, 18560f));
				
	}
	
}
