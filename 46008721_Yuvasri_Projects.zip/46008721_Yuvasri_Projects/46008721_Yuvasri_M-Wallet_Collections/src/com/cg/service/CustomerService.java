package com.cg.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.beans.Customer;
import com.cg.dao.CustomerDAO;
import com.cg.dao.ICustomerDAO;

public class CustomerService implements ICustomerService {
	
	ICustomerDAO customerDAO =new CustomerDAO();

	@Override
	public Customer addCustomer(Customer customer) {
		customerDAO.addCustomer(customer);
		return customer;
	}
	
	//get balance method
	public boolean getBalance(int accno)
	{
		return customerDAO.getBalance(accno);
	}
	
	
	//deposit method
	@Override
	public boolean deposit(int amt,int accNo) {
		return customerDAO.deposit(amt, accNo);
	}
	
	//withdraw amount method
	@Override
	public boolean withdrawAmt(int amt, int accNo) {
		return customerDAO.withdrawAmt(amt, accNo);
	}
	@Override
	public boolean fundTransfer(int amt, int acc1, int acc2) {
		return customerDAO.fundTransfer(amt, acc1, acc2);
	}
	@Override
	public boolean recentTransactions(int accNo) {
		return customerDAO.recentTransactions(accNo);
		
	}
	public boolean isValid(String s) {
        Pattern pattern=Pattern.compile("[6-9]{1}[0-9]{9}");
         Matcher matcher= pattern.matcher(s);
        return (matcher.find() && matcher.group().equals(s));
      
    }
    public boolean isValidEmailId(String s1){
        Pattern pattern1=Pattern.compile("^(.+)@(.+)$");
         Matcher matcher1= pattern1.matcher(s1);
        return (matcher1.find() && matcher1.group().equals(s1));
      
    }
    public boolean isValidName(String s2){
        Pattern pattern2=Pattern.compile("[A-Z]{1}([a-z])*");
         Matcher matcher2= pattern2.matcher(s2);
        return (matcher2.find() && matcher2.group().equals(s2));
      
    }

	
}
