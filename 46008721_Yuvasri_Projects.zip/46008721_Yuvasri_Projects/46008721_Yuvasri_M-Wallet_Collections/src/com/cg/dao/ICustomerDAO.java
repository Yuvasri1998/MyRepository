package com.cg.dao;

import com.cg.beans.Customer;

public interface ICustomerDAO {

	public Customer addCustomer(Customer customer);
	public boolean getBalance(int accno);
	public boolean deposit(int amt,int accNo);
	public boolean withdrawAmt(int amt,int accNo);
	public boolean fundTransfer(int amt,int acc1,int acc2);
	public boolean recentTransactions(int accNo);
}
