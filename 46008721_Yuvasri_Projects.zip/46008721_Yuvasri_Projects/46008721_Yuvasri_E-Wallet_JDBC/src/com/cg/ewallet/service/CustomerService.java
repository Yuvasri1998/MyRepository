package com.cg.ewallet.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ewallet.bean.AccountBean;
import com.cg.ewallet.bean.CustomerBean;
import com.cg.ewallet.dao.DAOClass;
import com.cg.ewallet.dao.IDAO;
import com.cg.ewallet.exceptions.Validations;

public class CustomerService implements ICustomerService {
	Scanner scan = new Scanner(System.in);
	CustomerBean customer;
	AccountBean account;
	IDAO dao;
	Validations valid = new Validations();
	
	@Override
	public void createAccount() {
		System.out.println("Enter your name: ");
		String custName = scan.next();
		valid.checkName(custName);
		System.out.println("Enter your phone number: ");
		long custPhoneNum = scan.nextLong();
		valid.checkPhoneNumber(custPhoneNum);
		System.out.println("Enter your email Id: ");
		String custemailID = scan.next();
		valid.checkEmailId(custemailID);
		System.out.println("Enter your Account Type from below categories: \n*Savings\n*Current\n*Fixed Deposit");
		String accType = scan.next();
		System.out.println("Enter amount: ");
		double accBalance = scan.nextDouble();
		
		customer = new CustomerBean();
		customer.setCustPhoneNum(custPhoneNum);
		customer.setCustName(custName);
		customer.setCustEmail(custemailID);
		
		account = new AccountBean();
		account.setAccountholdername(custName);
		account.setAccountType(accType);
		account.setBalance(accBalance);
		
		List<CustomerBean> custList = new ArrayList<>();
		custList.add(customer);
		//System.out.println("Customer table created");
		
		dao = new DAOClass();
		int status = dao.createCustomer(customer,account);		
		if (status == 1) {
			System.out.println("Your Account has been created.");
		} else {
			System.out.println("Please try some other time.");
		}
	}
	
	public void viewCustomerDetails() {
		
		dao = new DAOClass();
		customer = new CustomerBean();
		account = new AccountBean();
		System.out.println("Enter Account Id: ");
		Long accountId = scan.nextLong();
		ArrayList custList = dao.viewCustomerDetails(accountId);
		ArrayList accList = dao.getAllAccountDetails(accountId);
		System.out.println(accList);
		System.out.println(custList);
		
	}

}
