package com.cg.ewallet.service;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.ewallet.bean.AccountBean;
import com.cg.ewallet.bean.CustomerBean;
import com.cg.ewallet.dao.DAOClass;
import com.cg.ewallet.dao.IDAO;
import com.cg.ewallet.exceptions.Validations;

public class AccountService implements IAccountService {

	Scanner scan = new Scanner(System.in);
	IDAO dao;
	CustomerBean customer;
	AccountBean account;
	double availablebal;
	double receiverbal;
	Validations valid = new Validations();

	@Override
	public void showBalance() {
		System.out.println("ENTER ACCOUNT ID");
		int accountId = scan.nextInt();
		if (valid.checkExistance(accountId) == 1) {
			dao = new DAOClass();
			System.out.println("Your Account Balance is Rs. " + dao.showBalance(accountId));
		}
	}

	@Override
	public void depositAmount() {
		dao = new DAOClass();
		System.out.println("Enter your Account ID: ");
		int accountId = scan.nextInt();
		if (valid.checkExistance(accountId) == 1) {
			System.out.println("Enter amount to deposit:");
			int amt = scan.nextInt();
			String transactiontype = "credit";
			account = new AccountBean();
			availablebal = account.getUpdatingAmount(amt, dao.showBalance(accountId));
			account.setBalance(availablebal);
			double status = dao.updateBalance(amt, accountId, availablebal, transactiontype);
			if (status != 0) {
				System.out.println("Rs." + amt + " is credited to the account.");
				System.out.println("Total Balance: Rs." + availablebal);
			} else {
				System.err.println("Something is wrong with your bank server");
			}
		}
	}

	@Override
	public void withdrawAmount() {
		dao = new DAOClass();
		account = new AccountBean();
		System.out.println("Enter your Account ID: ");
		int accountId = scan.nextInt();
		if (valid.checkExistance(accountId) == 1) {
			System.out.println("Enter amount to withdraw:");
			int amt = scan.nextInt();
			valid.checkAmountValue(amt);
			String transactiontype = "debit";
			account = new AccountBean();
			if (dao.showBalance(accountId) > amt) {
				availablebal = account.getBalanceafterDeduction(amt, dao.showBalance(accountId));
				double status = dao.updateBalance(amt, accountId, availablebal, transactiontype);
				if (status != 0) {
					System.out.println("Rs." + amt + " is debited from the account.");
					System.out.println("Total Balance: Rs." + availablebal);
				} else {
					System.out.println("Something is wrong with your bank server");
				}
			} else {
				System.err.println("You don't have enough balance in your account");
			}
		}
	}

	@Override
	public void transferFund() {
		dao = new DAOClass();
		account = new AccountBean();
		System.out.println("Enter your Account ID: ");
		int accountId = scan.nextInt();
		if (valid.checkExistance(accountId) == 1) {
			System.out.println("Enter receiver Account ID: ");
			int receiverId = scan.nextInt();
			if (valid.checkExistance(receiverId) == 1) {
				System.out.println("Enter amount you want to transfer:");
				int amt = scan.nextInt();
				String transactiontype = " ";
				double updatedBal = 0;
				availablebal = dao.showBalance(accountId);
				if (availablebal >= amt) {
					updatedBal = account.getBalanceafterDeduction(amt, availablebal);
					transactiontype = "transfer";
					dao.updateBalance(amt, accountId, updatedBal, transactiontype);
					receiverbal = account.getUpdatingAmount(amt, dao.showBalance(receiverId));
					transactiontype = "received";
					dao.updateBalance(amt, receiverId, receiverbal, transactiontype);
					System.out.println("Transaction Successfull!!!");
				} else {
					System.err.println("Transaction failed!!!!");
				}
			}
		}
	}

	@Override
	public void printTransaction() {
		dao = new DAOClass();
		System.out.println("Enter Account Id: ");
		int accountId = scan.nextInt();
		if (valid.checkExistance(accountId) == 1) {
			ArrayList transactionList = dao.getAllTransactionDetails(accountId);
			System.out.println(transactionList);
		}
	}
}
