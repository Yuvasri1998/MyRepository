package com.cg.ewallet.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ewallet.bean.CustomerBean;

public interface ICustomerService {

	void createAccount();

	void viewCustomerDetails();


}
