package com.cg.ewallet.service;

public interface IAccountService {

	void showBalance();
	
	void depositAmount();

	void withdrawAmount();

	void transferFund();

	void printTransaction();

}
