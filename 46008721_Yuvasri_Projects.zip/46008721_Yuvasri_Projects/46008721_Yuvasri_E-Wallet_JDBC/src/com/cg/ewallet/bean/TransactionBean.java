package com.cg.ewallet.bean;

public class TransactionBean {
	private long accountId;
	private double creditAmount;
	private double debitAmount;
	private double totalBalance;
	private String transactionType;
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public double getTotalBalance() {
		return totalBalance;
	}
	public void setTotalBalance(double totalBalance) {
		this.totalBalance = totalBalance;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	@Override
	public String toString() {
		return "AccountId=" + accountId + ", CreditAmount=" + creditAmount + ", DebitAmount=" + debitAmount
				+ ", TotalBalance=" + totalBalance + ", TransactionType=" + transactionType + "\n";
	}
	
}
