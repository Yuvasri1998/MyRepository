package com.cg.ewallet.bean;

public class CustomerBean {
	
		private long custPhoneNum;
		private String custName;
		private String custEmail;
		private String accountholdername;
		private int accountId;
		public int getAccountId() {
			return accountId;
		}

		public void setAccountId(int accountId) {
			this.accountId = accountId;
		}

		private String accountType;
		private double balance;
		private double updatedBalance;
		
		public double getCustPhoneNum() {
			return custPhoneNum;
		}
		
		public void setCustPhoneNum(long custPhoneNum) {
			this.custPhoneNum = custPhoneNum;
		}
		
		public String getCustName() {
			return custName;
		}
		
		public void setCustName(String custName) {
			this.custName = custName;
		}
		

		public String getCustEmail() {
			return custEmail;
		}

		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}

		@Override
		public String toString() {
			return "PhoneNumber: " + custPhoneNum + "\nEmail ID: " + custEmail;
		}
		
		

}
