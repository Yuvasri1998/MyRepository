package com.cg.ewallet.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ewallet.bean.AccountBean;
import com.cg.ewallet.bean.CustomerBean;
import com.cg.ewallet.bean.TransactionBean;

public interface IDAO {

	int createCustomer(CustomerBean customer, AccountBean account);

	ArrayList viewCustomerDetails(long accountId);

	public double showBalance(int accountId);

	double updateBalance(int amount, int accountId, double balance, String transactiontype);

	ArrayList getAllAccountDetails(long accountId);
	
	public ArrayList<TransactionBean> getAllTransactionDetails(long accountId);


}
