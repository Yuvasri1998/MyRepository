package com.cg.ewallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.LongStream;

import com.cg.ewallet.bean.AccountBean;
import com.cg.ewallet.bean.CustomerBean;
import com.cg.ewallet.bean.TransactionBean;
import com.cg.ewallet.helper.DBConnect;

public class DAOClass implements IDAO {
	
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	Random rand = new Random();	
	double bal;
	AccountBean a;
	@Override
	public int createCustomer(CustomerBean customer, AccountBean account) {
		long l=0;
		try {
			con = DBConnect.getConnection();
			long accountid = rand.nextInt(1000);
			ps = con.prepareStatement("insert into customer values(?,?,?,"+accountid+")");
			ps.setString(1, customer.getCustName());
			ps.setDouble(2, customer.getCustPhoneNum());
			ps.setString(3, customer.getCustEmail());
			int row = ps.executeUpdate();
			a = new AccountBean();
			a.setAccountId(accountid);
			System.out.println("Your Account ID: "+a.getAccountId());
			//System.out.println("Customer Details created");
			ps = con.prepareStatement("insert into accountdetails values(?,"+accountid+",?,?)");
			ps.setString(1, account.getAccountholdername());
			ps.setString(2, account.getAccountType());
			ps.setDouble(3, account.getBalance());
			row = ps.executeUpdate();
			//System.out.println("Account Holder details are updated");
			
			ps = con.prepareStatement("insert into transactions(accountid, creditedamount, totalbalance, transactiontype) values("+accountid+",?,?,'deposited')");
			ps.setDouble(1, account.getBalance());
			ps.setDouble(2, account.getBalance());
            l = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 1;
	}
	
	public ArrayList<CustomerBean> viewCustomerDetails(long accountId) {
		ArrayList<CustomerBean> custList = new ArrayList<>();
		try {
			con = DBConnect.getConnection();
			ps = con.prepareStatement("select CustPhoneNum,CustEmailid from Customer where accountid = "+ accountId);
			rs = ps.executeQuery();
			while (rs.next()) { 
				CustomerBean c = new CustomerBean();
				c.setCustPhoneNum(rs.getLong(1));
				c.setCustEmail(rs.getString(2));
				custList.add(c);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custList;	
	}
	
	public ArrayList<AccountBean> getAllAccountDetails(long accountId) {
		ArrayList<AccountBean> accList = new ArrayList<>();
		try {
			con = DBConnect.getConnection();
			ps = con.prepareStatement("select * from AccountDetails where accountid = "+accountId);
			rs = ps.executeQuery();
			while (rs.next()) { 
				AccountBean a = new AccountBean();
				a.setAccountholdername(rs.getString(1));
				a.setAccountId(accountId);
				a.setAccountType(rs.getString(3));
				a.setBalance(rs.getDouble(4));
				accList.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accList;	
	}
	
	
	public ArrayList<TransactionBean> getAllTransactionDetails(long accountId) {
		ArrayList<TransactionBean> transactionList = new ArrayList<>();
		try {
			con = DBConnect.getConnection();
			ps = con.prepareStatement("select * from Transactions where accountid = "+accountId);
			rs = ps.executeQuery();
			while (rs.next()) { 
				TransactionBean transactiondetails = new TransactionBean();
				transactiondetails.setAccountId(accountId);
				transactiondetails.setCreditAmount(rs.getInt(2));
				transactiondetails.setDebitAmount(rs.getInt(3));
				transactiondetails.setTotalBalance(rs.getDouble(4));
				transactiondetails.setTransactionType(rs.getString(5));				
				transactionList.add(transactiondetails);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transactionList;	
	}
	
	//Show the Balance
	@Override
	public double showBalance(int accountId) {
		con = DBConnect.getConnection();
        try {
            ps = con.prepareStatement("select BALANCE from AccountDetails where ACCOUNTID=" + accountId);
            rs = ps.executeQuery();
            while (rs.next()) {
                bal = rs.getDouble("BALANCE");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bal;
	}
	
	
	@Override
    public double updateBalance(int amt, int accountId, double balance, String transactiontype) {
        con = DBConnect.getConnection();
        int l=0;
        try {
            ps = con.prepareStatement("update accountdetails set balance =" + balance +"where accountid =" +accountId);
            l = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }        
        if (transactiontype.contains("credit")) {
        	try {
        		ps = con.prepareStatement("insert into transactions(accountid, creditedamount, totalbalance, transactiontype) values("+accountId+","+amt+","+balance+",'deposited')");
        		rs = ps.executeQuery();
			} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
        } else if (transactiontype.contains("debit")) {
        	try {
        		ps = con.prepareStatement("insert into transactions(accountid, debitedamount, totalbalance, transactiontype) values("+accountId+","+amt+","+balance+",'withdrawn')");
        		rs = ps.executeQuery();
        	} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
        } else if (transactiontype.contains("transfer")) {
        	try {
        		ps = con.prepareStatement("insert into transactions(accountid, debitedamount, totalbalance, transactiontype) values("+accountId+","+amt+","+balance+",'transfered')");
        		rs = ps.executeQuery();
        	} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
        }else if (transactiontype.contains("received")) {
        	try {
        		ps = con.prepareStatement("insert into transactions(accountid, creditedamount, totalbalance, transactiontype) values("+accountId+","+amt+","+balance+",'received')");
        		rs = ps.executeQuery();
        	} catch (SQLException e) {
				System.out.println("Account Not Found");
			}
        }
        return l;
	}
}
