package com.cg.ewallet.view;

import java.util.Scanner;

import com.cg.ewallet.service.AccountService;
import com.cg.ewallet.service.CustomerService;
import com.cg.ewallet.service.IAccountService;
import com.cg.ewallet.service.ICustomerService;

public class MainPage {
	
	public static void main(String[] args) {
				
		ICustomerService customerService = new CustomerService();
		IAccountService accountService = new AccountService();
		Scanner scan = new Scanner(System.in);
		int key = 0;
		int choice = 0;
		do {
		System.out.println("WELCOME TO E-WALLET SERVICES");
		System.out.println("Select any option: ");
		System.out.println("1. Create Account");
		System.out.println("2. Show Balance");
		System.out.println("3. Deposit Amount");
		System.out.println("4. Withdraw Amount");
		System.out.println("5. Transfer Fund");
		System.out.println("6. Print Transaction");
		System.out.println("7. View Account Details");
		key = scan.nextInt();
		switch (key) {
		case 1:
			customerService.createAccount();
			break;
		case 2:
			accountService.showBalance();
			break;
		case 3:
			accountService.depositAmount();
			break;
		case 4:
			accountService.withdrawAmount();
			break;
		case 5:
			accountService.transferFund();
			break;
		case 6:
			accountService.printTransaction();
			break;
		case 7:
			customerService.viewCustomerDetails();
			break;
		default:
			System.out.println("Invalid Key");
			break;
		}
		
		System.out.println("Do you want to continue? \n1. Yes \n2. No");
		choice = scan.nextInt();
		
		} while (choice == 1);
	}

}
