package com.cg.ewallet.exceptions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ewallet.helper.DBConnect;

public class Validations extends RuntimeException {

	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	Pattern pattern;
	Matcher matcher;
	Validations validation;

	public int checkExistance(int accountId) {
		con = DBConnect.getConnection();
		SQLException accountInvalidException = new SQLException();
		int l = 1;
		try {
			ps = con.prepareStatement("select * from accountdetails where accountid =" + accountId);
			rs = ps.executeQuery();
			if (rs.next() != true) {
				l = 0;
				System.err.println("Invalid Account Number!!\n Please Try Again with Correct Account Number");
				throw accountInvalidException;
			}
		} catch (SQLException e) {
				accountInvalidException.printStackTrace();
		}
		return l;
	}

	public void checkPhoneNumber(long custPhoneNum) {
		validation = new Validations();
		try {
			pattern = Pattern.compile("(0/91)?[6-9][0-9]{9}$");
			matcher = pattern.matcher(String.valueOf(custPhoneNum));
			if (!(matcher.matches())) {
				System.err.println("Please enter a valid contact number");
				throw validation;
			}
		} catch (Validations PhoneNumberException) {
			PhoneNumberException.printStackTrace();
			System.exit(0);
		}
	}

	public void checkAmountValue(long amount) {
		validation = new Validations();
		try {
			if (amount % 100 != 0) {
				System.err.println("Transaction Failed!!!\nPlease withdraw amount in multiples of Rs. 100");
				throw validation;
			}
		} catch (Validations MoneyException) {
			MoneyException.printStackTrace();
			System.exit(0);
		}
	}

	public void checkName(String custname) {
		validation = new Validations();
		try {
			pattern = Pattern.compile("([A-Z])*([a-z])*$");
			matcher = pattern.matcher(custname);
			if (!(matcher.matches())) {
				System.err.println("Please enter a proper name");
				throw validation;
			}
		} catch (Validations NameException) {
			NameException.printStackTrace();
			System.exit(0);
		}
	}

	public void checkEmailId(String custemailID) {
		validation = new Validations();
		try {
			pattern = Pattern.compile("^(.+)@(.+)$");
			matcher = pattern.matcher(custemailID);
			if (!(matcher.matches())) {
				System.err.println("Please enter a valid email id");
				throw validation;
			}
		} catch (Validations NameException) {
			NameException.printStackTrace();
			System.exit(0);
		}
	}
}
