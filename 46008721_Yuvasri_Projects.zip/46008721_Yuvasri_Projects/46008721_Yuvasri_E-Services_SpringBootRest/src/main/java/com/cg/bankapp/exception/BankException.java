/**
 *
 *@Author: N.Yuvasri   
 *
 *Date :12/05/2019
 *
 *Description: Class for handling exceptions running program
 */

package com.cg.bankapp.exception;

public class BankException extends Exception {
public BankException()
{
	super();
}
public BankException(String msg)
{
	super(msg);
}
}

