package com.cg;

import org.openqa.selenium.WebDriver;

public class VerifyHomePage {

	@org.testng.annotations.Test
	public void VerifyHomePage() {
		WebDriver driver;
		
		driver.get("http://www.google.com/");
	}
}
