package com.cg.stepdef;

public class LoginStep {

}
