package com.cg.stepdefinition;

import static org.hamcrest.CoreMatchers.hasItems;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class MockStep {
	WebDriver driver;
	MockPage mp;
	
	@Given("^displaying comedy show form$")
	public void displaying_comedy_show_form() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:\\Users\\YNARAHAR\\SeliniumBDD\\MockBDD\\src\\main\\resources\\ComedyShow.html");
		driver.manage().window().maximize();
	}

	@When("^validating the form page title$")
	public void validating_the_form_page_title() throws Throwable {
		if (!driver.getTitle().equals("Add ComedyShow Form")) {
			driver.close();
		}
	}

	@When("^user enters empty show id and submit$")
	public void user_enters_empty_show_id_and_submit() throws Throwable {
		mp = new MockPage(driver);
		mp.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		mp.NoenterShowId();
	}
	
	@Then("^user enters blank show id and submit$")
	public void user_enters_blank_show_id_and_submit() throws Throwable {
		mp = new MockPage(driver);
		mp.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		mp.enterShowId();
	}

	@When("^user enters empty show title and submit$")
	public void user_enters_empty_show_title_and_submit() throws Throwable {
		mp.clickSubmit();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    mp.enterShowTitle();
	}

	@When("^user enters empty release date and submit$")
	public void user_enters_empty_release_date_and_submit() throws Throwable {
		mp.clickSubmit();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    mp.enterReleaseDate();
	}

	@When("^user enters empty comedian and submit$")
	public void user_enters_empty_comedian_and_submit() throws Throwable {
		mp.clickSubmit();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    mp.enterComedianName();
	}

	@When("^user enters empty show duration and submit$")
	public void user_enters_empty_show_duration_and_submit() throws Throwable {
		mp.clickSubmit();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    mp.enterShowDuration();
	}

	@When("^user selects empty language and submit$")
	public void user_selects_empty_language_and_submit() throws Throwable {
		mp.clickSubmit();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    mp.enterLaguage();
	}

	@When("^user selectss empty rating and submit$")
	public void user_selectss_empty_rating_and_submit() throws Throwable {
		mp.clickSubmit();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    mp.enterRating();
	}

	@Then("^appears success page$")
	public void appears_success_page() throws Throwable {
		mp.clickSubmit();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	}

	@Then("^quiting the window$")
	public void quiting_the_window() throws Throwable {
	   driver.close();
	}

}
