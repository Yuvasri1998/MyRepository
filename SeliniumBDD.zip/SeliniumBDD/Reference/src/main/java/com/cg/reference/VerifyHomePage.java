package com.cg.reference;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class VerifyHomePage {
	WebDriver driver;
	
	    @When("^user runs the browser$")
		public void user_runs_the_browser() throws Throwable {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
			driver = new ChromeDriver();
		    driver.manage().window().maximize();
			driver.get("http://www.google.com");
		    String expectedTitle="Google";
		    String actualTitle = driver.getTitle();
	}
		@Then("^title should match$")
		public void title_should_match() throws Throwable {
			Assert.assertEquals("Google", driver.getTitle());
			driver.close();
		}

}
