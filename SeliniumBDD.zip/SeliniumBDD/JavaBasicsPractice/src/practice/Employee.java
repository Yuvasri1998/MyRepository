package practice;

import java.util.Scanner;

class Employee
{ 
	public int empId; 
	public String empName; 
	public int empSalary;
	
	
	
	public int getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public Employee(int empId, String empName, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	} 

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}

	public static void main (String[] args) throws EmployeeIDNotFoundException 
	{ 
		Scanner sc = new Scanner(System.in);
		Employee[] arr = new Employee[5]; 
		arr[0] = new Employee(1,"aman",12000); 
		arr[1] = new Employee(2,"vaibhav",13000); 
		arr[2] = new Employee(3,"shikar",14000); 
		arr[3] = new Employee(4,"dharmesh",17000); 
		arr[4] = new Employee(5,"mohit",25000); 
		
		System.out.println("Employee Id:");
		int id = sc.nextInt();
		findById(arr,id);
	}

	private static void findById(Employee[] arr, int id) throws EmployeeIDNotFoundException {
		// TODO Auto-generated method stub
		for (int i = 0; i < arr.length; i++) {
			if (id == arr[i].getEmpId()) {
				System.out.println(arr[i]);
				System.exit(0);
			}
		}
		
			throw new EmployeeIDNotFoundException("Employee with ID "+id+" is not found!!!");
	}
}
