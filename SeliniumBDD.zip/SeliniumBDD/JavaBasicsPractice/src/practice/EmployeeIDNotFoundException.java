package practice;

public class EmployeeIDNotFoundException extends Exception{
	public EmployeeIDNotFoundException(String msg) {
		super(msg);
	}
}
