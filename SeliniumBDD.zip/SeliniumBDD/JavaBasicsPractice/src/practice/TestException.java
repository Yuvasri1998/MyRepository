package practice; 

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class TestException {

	public static void main(String[] args) {
		TestException te = new TestException();
		te.pracException();
	}
	
	public void pracException() {
		//int a;
		//a= 10/0;
		try {
			FileInputStream fis = new FileInputStream("C://One.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}

}
