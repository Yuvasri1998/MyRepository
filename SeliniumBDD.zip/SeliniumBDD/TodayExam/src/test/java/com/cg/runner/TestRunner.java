package com.cg.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\YNARAHAR\\SeliniumBDD\\TodayExam\\features",
glue=("com.cg.stepdefinitions"), dryRun=false)
public class TestRunner {

}
