package com.cg.stepdefinitions;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.EnquiryInfo;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EnquiryFormStepDefinition {
	WebDriver driver;
	EnquiryInfo info;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:/Users/YNARAHAR/Downloads/chromedriver.exe");
		driver = new ChromeDriver();
		info = new EnquiryInfo(driver);
	}
	
	@Given("^user is on 'Customer Enquiry Form'$")
	public void user_is_on_Customer_Enquiry_Form() throws Throwable {
	   driver.get("C:\\Users\\YNARAHAR\\SeliniumBDD\\TodayExam\\src\\test\\resources\\online_car_search.html");
	   driver.manage().window().maximize();
	}

	@Then("^the title should be 'Online Car Search' else stop execution$")
	public void the_title_should_be_Online_Car_Search_else_stop_execution() throws Throwable {
		//assertEquals("Online Car Search", driver.getTitle());
		if (driver.getTitle().equalsIgnoreCase("Online Car Search")) {
	    	System.out.println("User is on correct page");
	    } else {
	    	throw new PendingException();
	    }
	}

	@When("^user submits enquiry form without entering first name$")
	public void user_submits_enquiry_form_without_entering_first_name() throws Throwable {
	    info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'First name must be entered'$")
	public void alert_box_appears_as_First_name_must_be_entered() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("First Name must be filled out", alert.getText());
		alert.accept();
		info.enterFirstName();
	}

	@When("^user submits enquiry form without entering last name$")
	public void user_submits_enquiry_form_without_entering_last_name() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Last name must be entered'$")
	public void alert_box_appears_as_Last_name_must_be_entered() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Last Name must be filled out", alert.getText());
		alert.accept();
		info.enterLastName();
	}

	@When("^user submits enquiry form without entering email id$")
	public void user_submits_enquiry_form_without_entering_email_id() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Email must be filled out'$")
	public void alert_box_appears_as_Email_must_be_filled_out() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Email must be filled out", alert.getText());
		alert.accept();
		info.enterEmailID();
	}

	@When("^user submits enquiry form without entering mobile number$")
	public void user_submits_enquiry_form_without_entering_mobile_number() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Mobile must be filled out'$")
	public void alert_box_appears_as_Mobile_must_be_filled_out() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Mobile must be filled out", alert.getText());
		alert.accept();
		info.enterAlphabeticMobileNo();
	}

	@When("^user submits enquiry form by entering alphabets as mobile number$")
	public void user_submits_enquiry_form_by_entering_alphabets_as_mobile_number() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Enter numeric value'$")
	public void alert_box_appears_as_Enter_numeric_value() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Enter numeric value", alert.getText());
		alert.accept();
		info.enterInvalidMobileNo();
	}

	@When("^user submits enquiry form by entering less than or more than (\\d+) digit as mobile number$")
	public void user_submits_enquiry_form_by_entering_less_than_or_more_than_digit_as_mobile_number(int arg1) throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Enter (\\d+) digit Mobile number'$")
	public void alert_box_appears_as_Enter_digit_Mobile_number(int arg1) throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Enter 10 digit Mobile number", alert.getText());
		alert.accept();
		info.enterValidMobileNo();
	}

	@When("^user submits enquiry form without entering city preference$")
	public void user_submits_enquiry_form_without_entering_city_preference() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'City should be selected'$")
	public void alert_box_appears_as_City_should_be_selected() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("City should be selected", alert.getText());
		alert.accept();
		info.enterCity();
	}

	@When("^user submits enquiry form without entering car body type$")
	public void user_submits_enquiry_form_without_entering_car_body_type() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Car Body Type Should be selected'$")
	public void alert_box_appears_as_Car_Body_Type_Should_be_selected() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Car Body Type Should be selected", alert.getText());
		alert.accept();
		info.enterCarType();
	}

	@When("^user submits enquiry form without entering fuel type$")
	public void user_submits_enquiry_form_without_entering_fuel_type() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Fuel Type should be selected'$")
	public void alert_box_appears_as_Fuel_Type_should_be_selected() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Fuel Type should be selected", alert.getText());
		alert.accept();
		info.enterFuelType();
	}

	@When("^user submits enquiry form without entering seating capacity$")
	public void user_submits_enquiry_form_without_entering_seating_capacity() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Seating Capacity should be selected'$")
	public void alert_box_appears_as_Seating_Capacity_should_be_selected() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Seating Capacity should be selected", alert.getText());
		alert.accept();
		info.enterSeatingCapacity();
	}

	@When("^user submits enquiry form without entering enquiry details$")
	public void user_submits_enquiry_form_without_entering_enquiry_details() throws Throwable {
		info.clickSubmit();
	    Thread.sleep(10000);
	}

	@Then("^alert box appears as 'Enquiry details must be filled out'$")
	public void alert_box_appears_as_Enquiry_details_must_be_filled_out() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Enquiry details must be filled out", alert.getText());
		alert.accept();
		info.enterEnquiryDetails();
	}

	@When("^user submits enquiry form after validating the details entered$")
	public void user_submits_enquiry_form_after_validating_the_details_entered() throws Throwable {
		Thread.sleep(15000);
		info.clickSubmit();
	}

	@Then("^alert box appears as 'Thank you for submitting the online recipe class enquiry'$")
	public void alert_box_appears_as_Thank_you_for_submitting_the_online_recipe_class_enquiry() throws Throwable {
		Alert alert=driver.switchTo().alert();
		assertEquals("Thank you for submitting the online Car Search Details.", alert.getText());
		alert.accept();
	}
	
	@When("^validating the page title$")
	public void validating_the_page_title() throws Throwable {
		String s = info.pageInfo();
		assertEquals("Our location representative will contact you soon.", s);
	}

	@Then("^closing the web page$")
	public void closing_the_web_page() throws Throwable {
	    
	}


}
