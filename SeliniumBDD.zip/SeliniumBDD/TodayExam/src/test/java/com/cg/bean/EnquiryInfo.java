package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EnquiryInfo {

	@FindBy(id="fname")
	WebElement firstName;

	@FindBy(id = "lname")
	WebElement lastName;

	@FindBy(id = "emails")
	WebElement emailId;

	@FindBy(id = "mobile")
	WebElement mobileNo;
	
	@FindBy(id = "mobile")
	WebElement m1;

	@FindBy(id = "mobile")
	WebElement m2;


	@FindBy(xpath = "/html/body/form/table/tbody/tr[6]/td[2]/select")
	WebElement cityPreference;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[7]/td[2]/select")
	WebElement carBodyType;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[8]/td[2]/select")
	WebElement fuelType;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[9]/td[2]/select")
	WebElement seatingCapacity;

	@FindBy(id = "enqdetails")
	WebElement enquiryDetails;
	
	@FindBy(xpath = "//*[@id=\'Submit1\']")
	WebElement submit;
	
	@FindBy(xpath = "/html/body")
	WebElement successPageTitle;

	public EnquiryInfo(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void enterFirstName() {
		firstName.sendKeys("Yuvasri");
	}
	
	public void clickSubmit() {
		submit.click();
	}

	public void enterLastName() {
		lastName.sendKeys("Naraharisetti");
	}

	public void enterEmailID() {
		emailId.sendKeys("yuvi@gmail.com");
	}

	public void enterAlphabeticMobileNo() {
		mobileNo.sendKeys("abcdg");
	}

	public void enterInvalidMobileNo() {
		mobileNo.clear();
		mobileNo.sendKeys("6543212");
	}

	public void enterValidMobileNo() {
		mobileNo.clear();
		mobileNo.sendKeys("9182474413");
	}

	public void enterCity() {
		Select city = new Select(cityPreference);
        city.selectByValue("chennai");
	}

	public void enterFuelType() {
		Select fuel = new Select(fuelType);
        fuel.selectByValue("LPG");
	}
	
	public void enterCarType() {
		Select carType = new Select(carBodyType);
        carType.selectByValue("sedan");		
	}

	public void enterSeatingCapacity() {
		Select capacity = new Select(seatingCapacity);
        capacity.selectByValue("6-8");
	}

	public void enterEnquiryDetails() {
		enquiryDetails.sendKeys("I would like to know whether there is any new feature rather than above.");
	}	
	
	public String pageInfo() {
		return successPageTitle.getText();
	}
		
}
