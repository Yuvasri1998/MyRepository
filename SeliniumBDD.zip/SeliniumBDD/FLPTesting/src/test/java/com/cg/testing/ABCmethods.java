package com.cg.testing;

import org.testng.annotations.Test;

public class ABCmethods {
	
	@Test(priority = 1,dependsOnMethods="A")							//(invocationCount = 3)							//(priority = 1,dependsOnMethods="A")
	public void B() {
		System.out.println("B");
	}
	
	@Test
	public void C() {
		System.out.println("C");
	}
	
	@Test(expectedExceptions = ArithmeticException.class)
	public void A() {
		int a = 10/0;
		System.out.println("A");
	}
}
