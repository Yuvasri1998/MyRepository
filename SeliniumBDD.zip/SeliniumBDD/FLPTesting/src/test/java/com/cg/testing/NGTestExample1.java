package com.cg.testing;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.*;

import junit.framework.Assert;

public class NGTestExample1 {
	WebDriver driver;
	Actions actions;
	ChromeOptions options;
	
	@BeforeSuite
	public void init() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@BeforeTest
	public void launchPage() {
		driver.get("http://www.myntra.com");
	}
	
	@Test
	public void testHomePage() {
		Assert.assertEquals(driver.getTitle(), "Online Shopping for Women, Men, Kids Fashion & Lifestyle - Myntra");
	}	
	
	@Test(priority = 1)
	public void profilePageCheck() {
		//Assert.assertEquals(driver.getTitle(), "Online Shopping for Women, Men, Kids Fashion & Lifestyle - Myntra");
		WebElement profile = driver.findElement(By.xpath("//*[@id=\'desktop-header-cnt\']/div[2]/div[2]/div/div[1]/span[2]"));
		actions = new Actions(driver); 
		actions.moveToElement(profile).build().perform();
		WebElement logPage = driver.findElement(By.xpath("//*[@id=\'desktop-header-cnt\']/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[2]"));
		logPage.click();
		//System.out.println(driver.getTitle());
		//Assert.assertEquals(driver.getTitle(), "Login");
	}
	
	@Test(priority = 2)
	public void wrongCredentials() {
		System.out.println(driver.getTitle());
		Assert.assertEquals(driver.getTitle(), "Login");
		WebElement userName = driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
		userName.sendKeys("yuvasri@gmail.com");
		WebElement pswd = driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
		pswd.sendKeys("yuvi@1234");
		driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[2]/button")).click();
		Assert.assertEquals(driver.getTitle(), "Login");
	}
	
	
	
	/*@AfterSuite
	public void Quiting() {
		driver.quit();
	}*/
}
