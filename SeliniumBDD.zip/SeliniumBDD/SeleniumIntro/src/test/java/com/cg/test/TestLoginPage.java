package com.cg.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class TestLoginPage {
	WebDriver driver;
	
}
