package com.cg.test;

import org.testng.annotations.*;

public class TestJava1 {
	@BeforeSuite
	public void beforeSuitemethod() {
		System.out.println("Using @BeforeSuite annotation");
	}
	
	@BeforeTest
	public void beforeTestmethod() {
		System.out.println("Using @BeforeTest annotation");
	}
	
	@BeforeMethod
	public void beforeMethodmethod() {
		System.out.println("Using @BeforeMethod annotation");
	}
	
	@Test
	public void test1() {
		System.out.println("Using @Test annotation 1");
	}
	
	@Test
	public void test2() {
		System.out.println("Using @Test annotation 2");
	}
}
