package com.cg.test;

import org.testng.annotations.*;

public class TestJava2 {
	
	
	@AfterTest
	public void afterTestmethod() {
		System.out.println("Using @AfterTest annotation");
	}
	
	@AfterMethod
	public void afterMethodmethod() {
		System.out.println("Using @AfterMethod annotation");
	}
	
	@Test
	public void test1() {
		System.out.println("Using @Test annotation 1");
	}
	
	@Test
	public void test2() {
		System.out.println("Using @Test annotation 2");
	}
	
	@AfterSuite
	public void afterSuitemethod() {
		System.out.println("Using @AfterSuite annotation");
	}
}
