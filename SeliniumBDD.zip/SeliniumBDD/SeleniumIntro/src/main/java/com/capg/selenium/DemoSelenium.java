package com.capg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoSelenium {
	public static void main(String[] args) {
		
		//setting the chrome driver executable file path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com"); 
		
		// 'http://' is the protocal must be mentioned to run the driver
		/*System.out.println(driver.getTitle());
		System.out.println(driver.getPageSource());
		driver.getPageSource();
		driver.getTitle();
		driver.close();
		driver.quit();*/
		
		//Using "by.name" locator
		
		/*WebElement searchElement = driver.findElement(By.name("q"));
		searchElement.sendKeys("apple");
		searchElement.submit();
		if (driver.getTitle().equalsIgnoreCase("apple - Google Search")) {
			System.out.println("Current Page");
		} else {
			System.out.println("Incorrect");
		}*/
		
		//Using "by.linkText" locator
		/*driver.get("http://www.google.com"); 
		WebElement searchElement1 = driver.findElement(By.linkText("Images"));
		searchElement1.click();*/
		
		//Using "by.xpath" locator
		WebElement search=driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		search.sendKeys("mango");
		search.submit();
	}
}
