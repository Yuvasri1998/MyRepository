package com.capg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class MyntraExample {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		
		WebDriver driver = new ChromeDriver(options);
		driver.get("http://www.myntra.com");
		driver.manage().window().maximize();
		Actions action = new Actions(driver);
		WebElement menSection = driver.findElement(By.xpath("//*[@id=\'desktop-header-cnt\']/div[2]/nav/div/div[1]/div/a"));
		action.moveToElement(menSection).build().perform();
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/header[1]/div[2]/nav[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/li[5]/ul[1]/li[14]/a[1]")).click();
		//driver.findElement(By.className("desktop-categoryName"));
		if (driver.getTitle().equalsIgnoreCase("Mens Bags & Backpacks - Buy Bags & Backpacks for Men Online")) {
			System.out.println("Correct Page");
			driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/main/div[3]/div[1]/section/div/div[2]/ul/li[1]/label")).click();
			driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/main[1]/div[3]/div[2]/div[1]/div[2]/section[1]/ul[1]/li[26]/a[1]/div[1]/div[1]")).click();
			System.out.println(driver.getTitle());
			driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/main/div[2]/div[2]/div[3]/div/div[2]")).click();
		} else {
			System.out.println("Incorrect Page");
		}		
	}
}
