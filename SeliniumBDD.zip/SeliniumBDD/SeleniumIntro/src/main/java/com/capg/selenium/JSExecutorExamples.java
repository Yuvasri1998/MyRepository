package com.capg.selenium;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JSExecutorExamples {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//Using JavaScriptExecutor Interface
		driver.get("file:///C:/Users/YNARAHAR/SeliniumBDD/SeleniumIntro/src/main/resources/FormsFile.html");
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		//for Alert() function
		//js.executeScript("alert('hello World!!')"); 
		
		//for Scrolling function
		js.executeScript("window.scrollBy(0, document.body.scrollHeight)"); 
	}
}
