package com.capg.selenium;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExpectedConditionsExamples {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		WebElement P = null; 
		WebDriverWait w = new WebDriverWait(driver,20); 
		w.ignoring(NoSuchElementException.class); 
		//below statement will wait until element becomes visible 
		P=w.until(ExpectedConditions.visibilityOfElementLocated(By.id("x"))); 
		//below statement will wait until element becomes clickable. 
		P= w.until(ExpectedConditions.elementToBeClickable(By.id("ss")));
	}
}
