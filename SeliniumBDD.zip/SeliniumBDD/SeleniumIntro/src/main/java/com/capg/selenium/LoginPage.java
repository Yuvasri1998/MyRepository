package com.capg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginPage {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/YNARAHAR/SeliniumBDD/SeleniumIntro/src/main/resources/LoginPage.html"); 
		WebElement searchElement;
		searchElement = driver.findElement(By.name("userName"));
		searchElement.sendKeys("yuvasri");
		searchElement = driver.findElement(By.name("pswd"));
		searchElement.sendKeys("Yuvi@1234");
		searchElement = driver.findElement(By.id("submit"));
		searchElement.getText();
		searchElement.click();	
	}
}
