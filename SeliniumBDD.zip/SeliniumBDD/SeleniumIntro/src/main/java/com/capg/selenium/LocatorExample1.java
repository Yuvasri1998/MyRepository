package com.capg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LocatorExample1 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com"); 
		WebElement searchElement = driver.findElement(By.linkText("REGISTER"));
		searchElement.click();
		//System.out.println(driver.getTitle());
		searchElement = driver.findElement(By.name("firstName"));
		searchElement.sendKeys("yuvasri");
		searchElement = driver.findElement(By.name("lastName"));
		searchElement.sendKeys("naraharisetti");
		searchElement = driver.findElement(By.name("phone"));
		searchElement.sendKeys("9133445566");
		searchElement = driver.findElement(By.name("userName"));
		searchElement.sendKeys("yuvi@gmail.com");
		searchElement = driver.findElement(By.name("address1"));
		searchElement.sendKeys("H.No.3-3-73, Shantinagar,");
		searchElement = driver.findElement(By.name("address2"));
		searchElement.sendKeys("Baghameer, Kukatpally");
		searchElement = driver.findElement(By.name("city"));
		searchElement.sendKeys("Hyderabad");
		searchElement = driver.findElement(By.name("state"));
		searchElement.sendKeys("Telangana");
		searchElement = driver.findElement(By.name("postalCode"));
		searchElement.sendKeys("500072");
		Select s = new Select(driver.findElement(By.name("country"))); //Using 'Select' interface
		s.selectByValue("92");
		searchElement = driver.findElement(By.name("email"));
		searchElement.sendKeys("YNARAHAR");
		searchElement = driver.findElement(By.name("password"));
		searchElement.sendKeys("Aaa@1234");
		searchElement = driver.findElement(By.name("confirmPassword"));
		searchElement.sendKeys("Aaa@1234");
		searchElement.submit();		
	}
}
