package com.capg.selenium;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ActivityDay1 {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/YNARAHAR/SeliniumBDD/SeleniumIntro/src/main/resources/FormsFile.html"); 
		WebElement searchElement;
		searchElement = driver.findElement(By.name("userName"));
		searchElement.sendKeys("yuvasri");
		searchElement = driver.findElement(By.name("pswd"));
		searchElement.sendKeys("Yuvi@1234");
		searchElement = driver.findElement(By.name("female"));
		searchElement.click();
		List<WebElement> l =driver.findElements(By.name("lang"));
        Iterator<WebElement> i =l.iterator();
        while(i.hasNext()) {
            WebElement element =i.next();
            String value = element.getAttribute("value");
            if(value.equalsIgnoreCase("Hindi")||value.equalsIgnoreCase("English")) {
                element.click();
            }
        }
		Select s = new Select(driver.findElement(By.name("country"))); 
		s.selectByValue("India");
		searchElement = driver.findElement(By.linkText("Click Here for Google"));
		searchElement.click();
		driver.navigate().back();
		searchElement = driver.findElement(By.name("image"));
		searchElement.click();
		driver.navigate().back();
		driver.findElement(By.id("submit")).click();
		driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //Using implicitlyWait() method
		driver.switchTo().alert().accept();
		searchElement = driver.findElement(By.name("pswd"));
		searchElement.sendKeys("Yuvi@1234");
		searchElement = driver.findElement(By.id("submit"));
		searchElement.getText();
		searchElement.click();	
	}
}