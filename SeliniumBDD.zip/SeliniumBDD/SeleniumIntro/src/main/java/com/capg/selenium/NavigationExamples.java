package com.capg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigationExamples {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		WebElement searchElement = driver.findElement(By.name("q"));
		searchElement.sendKeys("apple");
		searchElement.submit();
		driver.navigate().back();
		searchElement = driver.findElement(By.name("q"));
		searchElement.sendKeys("roses");
		searchElement.submit();
		driver.navigate().back();
		//driver.navigate().forward();
	}
}
