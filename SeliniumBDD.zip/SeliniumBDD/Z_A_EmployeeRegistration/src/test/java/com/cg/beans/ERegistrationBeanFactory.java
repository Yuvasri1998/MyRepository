package com.cg.beans;

public class ERegistrationBeanFactory {

}
