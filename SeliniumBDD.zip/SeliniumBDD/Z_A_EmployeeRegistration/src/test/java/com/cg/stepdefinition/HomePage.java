package com.cg.stepdefinition;

public class HomePage {

}
