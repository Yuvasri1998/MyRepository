package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\YNARAHAR\\SeliniumBDD\\FLPcucumber\\feature",
glue="stepdef", dryRun = false, monochrome = true, format = "json:test-output/cucumber.json")
//For .xml file: (format = "junit:test-output/cucumber.xml)
//For .json file: (format = "json:test-output/cucumber.json")
public class TestRunner {

}
