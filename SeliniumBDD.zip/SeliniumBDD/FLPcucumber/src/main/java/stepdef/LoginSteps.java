package stepdef;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginSteps {
	WebDriver driver;
	Actions action;
	LoginPage login;
	ChromeOptions options;

	@Given("^user is on Myntra login page$")
	public void user_is_on_Myntra_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\YNARAHAR\\Downloads\\chromedriver.exe");
		options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://www.myntra.com");
		login = new LoginPage(driver);
		login.clickProfile();
		login.clickLogin();
	}

	
	@When("^user enters username and password$")
	public void user_enters_username_and_password() throws Throwable {
		login.EnterUser();
		login.clickLoginButton();
	}

	/*
	 * @When("^user enters \"([^\"]*)\" & \"([^\"]*)\"$") public void
	 * user_enters(String uName, String password) throws Throwable { // Write code
	 * here that turns the phrase above into concrete actions WebElement userName =
	 * driver .findElement(By.xpath(
	 * "//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
	 * userName.sendKeys(uName); WebElement pswd = driver .findElement(By.xpath(
	 * "//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input"));
	 * pswd.sendKeys(password); pswd.click(); //throw new PendingException(); }
	 */

//	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
//	public void user_enters_and(String uName, String password) throws Throwable {
//		WebElement userName = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
//		userName.sendKeys(uName);
//		WebElement pswd = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input"));
//		pswd.sendKeys(password);
//		pswd.click();
//	}
//
//	@When("^user enters empty username \"([^\"]*)\" & \"([^\"]*)\"$")
//	public void user_enters_empty_username(String uName, String password) throws Throwable {
//		WebElement userName = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
//		userName.sendKeys(uName);
//		WebElement pswd = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input"));
//		pswd.sendKeys(password);
//		pswd.click();
//	}
//
//	@When("^user enters empty password \"([^\"]*)\" & \"([^\"]*)\"$")
//	public void user_enters_empty_password(String uName, String password) throws Throwable {
//		WebElement userName = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
//		userName.sendKeys(uName);
//		WebElement pswd = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input"));
//		pswd.sendKeys(password);
//		pswd.click();
//	}
//
//	@When("^user enters username and password$")
//	public void user_enters_username_and_password(DataTable arg1) throws Throwable {
//		// Write code here that turns the phrase above into concrete actions
//		// For automatic transformation, change DataTable to one of
//		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
//		// E,K,V must be a scalar (String, Integer, Date, enum etc)
//		List<List<String>>list = arg1.raw();
//		WebElement userName = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input"));
//		userName.sendKeys(list.get(0).get(0));
//		WebElement pswd = driver
//				.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input"));
//		pswd.sendKeys(list.get(0).get(1));
//		pswd.click();
//		//throw new PendingException();
//	}

	@When("^user clicks on submit$")
	public void user_clicks_on_submit() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[2]/button")).click();
		// throw new PendingException();
	}

	@Then("^Home page must appear$")
	public void home_page_must_appear() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		// throw new PendingException();
	}
}
