package stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	@FindBy(xpath="//*[@id=\'desktop-header-cnt\']/div[2]/div[2]/div/div[1]/span[2]")
	WebElement profile;
	
	@FindBy(xpath="//*[@id=\'desktop-header-cnt\']/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[2]")
	WebElement login;
	
	@FindBy(xpath="//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input")
	WebElement username;
	
	@FindBy(xpath="//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input")
	WebElement password;
	
	@FindBy(xpath="//*[@id=\'mountRoot\']/div/div/div/form/fieldset[2]/button")
	WebElement loginbtn;
	
	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void clickProfile() {
		profile.click();
	}
	
	public void clickLogin() {
		login.click();
	}
	
	public void EnterUser() {
		username.sendKeys("capg");
		password.sendKeys("capg1234");
	}
	
	public void clickLoginButton() {
		loginbtn.click();
	}
}
